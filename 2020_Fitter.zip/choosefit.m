%Fitting algorithm for multiple Gaussians - need ezfit toolbox

if numberpeaks(z) ==0;
        fit.m  = zeros(1,10);
elseif numberpeaks(z) == 1;
    ampa = double(Q(z,a)-off);
    fit = ezfit(Q(z,:),'ampa*exp(-(x-a)^2/(2*s^2))+off', [ampa a off s]);
elseif numberpeaks(z) == 2;
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off);
    fit = ezfit(Q(z,:),'amp1*exp(-(x-a)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+off', [amp1 amp2 a b off s]);
elseif numberpeaks(z) == 3;
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off); amp3 = double(Q(z,c)-off);
    fit = ezfit(Q(z,:),'amp3*exp(-(x-c)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+amp1*exp(-(x-a)^2/(2*s^2))+off', [amp1 amp2 amp3 a b c off s]);
elseif numberpeaks(z) == 4;
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off); amp3 = double(Q(z,c)-off); amp4 = double(Q(z,d)-off);
    fit = ezfit(Q(z,:),'amp4*exp(-(x-d)^2/(2*s^2))+amp3*exp(-(x-c)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+amp1*exp(-(x-a)^2/(2*s^2))+off', [amp1 amp2 amp3 amp4 a b c d off s]);
elseif numberpeaks(z) == 5; %need to finish from here onwards
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off); amp3 = double(Q(z,c)-off); amp4 = double(Q(z,d)-off);amp5 = double(Q(z,e)-off);
    fit = ezfit(Q(z,:),'amp5*exp(-(x-e)^2/(2*s^2))+amp4*exp(-(x-d)^2/(2*s^2))+amp3*exp(-(x-c)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+amp1*exp(-(x-a)^2/(2*s^2))+off', [amp1 amp2 amp3 amp4 amp5 a b c d e off s]);
elseif numberpeaks(z) == 6;
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off); amp3 = double(Q(z,c)-off); amp4 = double(Q(z,d)-off);amp5 = double(Q(z,e)-off); amp6 = double(Q(z,f)-off);
    fit = ezfit(Q(z,:),'amp6*exp(-(x-f)^2/(2*s^2))+amp5*exp(-(x-e)^2/(2*s^2))+amp4*exp(-(x-d)^2/(2*s^2))+amp3*exp(-(x-c)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+amp1*exp(-(x-a)^2/(2*s^2))+off', [amp1 amp2 amp3 amp4 amp5 amp6 a b c d e f off s]);
elseif numberpeaks(z) == 7;
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off); amp3 = double(Q(z,c)-off); amp4 = double(Q(z,d)-off);amp5 = double(Q(z,e)-off); amp6 = double(Q(z,f)-off); amp7 = double(Q(z,g)-off);
    fit = ezfit(Q(z,:),'amp7*exp(-(x-g)^2/(2*s^2))+amp6*exp(-(x-f)^2/(2*s^2))+amp5*exp(-(x-e)^2/(2*s^2))+amp4*exp(-(x-d)^2/(2*s^2))+amp3*exp(-(x-c)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+amp1*exp(-(x-a)^2/(2*s^2))+off', [amp1 amp2 amp3 amp4 amp5 amp6 amp7 a b c d e f g off s]);
elseif numberpeaks(z) == 8;
    amp1 = double(Q(z,a)-off); amp2 = double(Q(z,b)-off); amp3 = double(Q(z,c)-off); amp4 = double(Q(z,d)-off);amp5 = double(Q(z,e)-off); amp6 = double(Q(z,f)-off); amp7 = double(Q(z,g)-off); amp8 = double(Q(z,h)-off);
    fit = ezfit(Q(z,:),'amp8*exp(-(x-h)^2/(2*s^2))+amp7*exp(-(x-g)^2/(2*s^2))+amp6*exp(-(x-f)^2/(2*s^2))+amp5*exp(-(x-e)^2/(2*s^2))+amp4*exp(-(x-d)^2/(2*s^2))+amp3*exp(-(x-c)^2/(2*s^2))+amp2*exp(-(x-b)^2/(2*s^2))+amp1*exp(-(x-a)^2/(2*s^2))+off', [amp1 amp2 amp3 amp4 amp5 amp6 amp7 amp8 a b c d e f g h off s]);
end
fitline(z,1:size(fit.m,2)+1) = [numberpeaks(z) fit.m];

'too many peaks';

