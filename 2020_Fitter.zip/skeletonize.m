
idealJ = J; counter = 0; pixel = 2;

for linescan = 1:size (J,1);

    while pixel < size(J,2);
         test = J(linescan,(pixel+counter));
         while J(linescan,(pixel+counter)) >0 && J(linescan,(pixel+counter-1)) >0;
            
             counter = counter + 1;
             if pixel+counter > size(J,2)
                 counter = counter -1; break
             end
         end
         if counter > 0;
            idealJ(linescan,(pixel-1:pixel+counter-1)) = 0;
            idealJ(linescan,pixel+floor(counter/2)) = 255;
         end
         pixel = pixel + counter+1;
         counter = 0;
    end





pixel = 2;

end


subplot (plotpanel);
imagesc (idealJ); figure(gcf); colormap(gray); %freezeColors
