if numberpeaks(z) ==1;
yfit1 = ampa*exp(-((1:wdth)-a).^2/(2*s^2))+off;
elseif numberpeaks(z) ==2;
yfit2 = amp1*exp(-((1:wdth)-a).^2/(2*s^2))+amp2*exp(-((1:wdth)-b).^2/(2*s^2))+off;
end
diff = yfit1-yfit2;
plot (diff);