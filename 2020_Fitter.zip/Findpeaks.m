A=find(idealJ);
[nopeaks,peakpos] = ind2sub(size(Q),A);
Z = [nopeaks,peakpos];
sorted = sortrows(Z,1);