kymographfit;
Thresholding;
Findpeaks;
Fitpeaks;
