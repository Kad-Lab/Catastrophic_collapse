thresh = mean(Q(:))+50;
J = (Q > thresh);
J(J>0)=255;
subplot (154);
imagesc (J); figure(gcf); colormap(gray)
plotpanel = 155;
skeletonize;