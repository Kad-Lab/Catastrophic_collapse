clf; inc = 0;cumpeakpos = 1;
off=double(mean(mean(Q))); amp=50; s=3; m = zeros(1,8); 
 pause on; z =1; 
%  while z <= 11; % uncomment for testing and comment the next line 
 while z <= max(nopeaks);
    numberpeaks(z)  = size(nopeaks(nopeaks==z),1);

    m(1:numberpeaks(z)) = sorted(cumpeakpos:numberpeaks(z)+cumpeakpos-1,2);%peakpos_for_nopeaks_value;
    cumpeakpos = cumpeakpos+numberpeaks(z);
    a = m(1); b= m(2); c = m(3); d= m(4); e =m(5); f = m(6); g =m(7); h =m(8);
    
    choosefit;
    %Peak_difference;
  
    plot(Q(z,:)); hold on; plot(1:wdth,evalfit(fit,1:wdth),'r-');axis([0 wdth min(min(Q)) max(max(Q))]); hold off; rmfit('last');
    pause (0.1); %Change this value to higher to slow or lower to speed up
 m = zeros(1,8);
 z = z + 1;
 end
% The data is stored in the variable fitline (see choosefit.m). Fitline
% stores the first value as the number of peaks that were identified and
% then the remainder of that line are the parameters from fit.m used in
% choosefit.m. These have been sorted as below:

%This code puts fitline into columns, the first is the #fits, next 8
%amplitudes (any zeros mean no fit), next 8 are means, final two are offset
%and SD. Use sorted_fitline instead of fitline
sorted_fitline = zeros(size (fitline,1),19); %size (fitline,2)); Now hardcoded to 8 fits
max_fit = 8; %(size (fitline,2) -3)/2; This bit of code does the size calc automatically
fitno = 0;
for q = 1:size (fitline,1); %setup loop to bottom of fitline
fitno = fitline(q,1); %how many fits? Next line resorts the data
sorted_fitline(q,:) = [fitno fitline(q,2:(1+fitno)) zeros(1,(max_fit-fitno)) fitline(q,2+fitno:(2*fitno+1)) zeros(1,(max_fit-fitno)) fitline(q,(2*fitno+2):(2*fitno+3)) ];
end