clear;

[FileName,PathName,FilterIndex] = uigetfile('*.tif', 'MultiSelect', 'on');
cd(PathName);
delimiter = ' ';
Q=single(importdata(FileName)); %Insert file name here for vertical kymograph
% Test data is called 'Cooperative activation.tif'

% Av_value=mean(mean(Q(1:200,1:215)));
thresh =65; pos = 0;
wdth = size(Q,2); % array size in x
lngth = size(Q,1); % array size in y

% Calculate the mean for each row and the max
for z=1:lngth;
av(z,1) = mean(Q(z,1:wdth));
maxi(z,1) = max(Q(z,1:wdth));
mini = mean(min(Q));
end

%2D sort of the data
for z = 3:lngth;
   % [val, xpos(z)] = max(J(z,:));
for step = 3:wdth-1;
if Q(z,1)<mini+10; %mean(av); %set threshold, if below make zero
    J(z,step)=0;
elseif (Q(z,step)>mini+thresh)&&(Q(z,step-1)>mini+thresh)&&(Q(z,step+1)>mini+thresh)&&(Q(z-1,step)>mini+thresh); %if equal to max make 255
    % You can't do this for all rows because some contain only noise and we
    % would be assigning a value of 255 to the max noise value, hence the
    % threshold
    pos = pos + 1;
%     jump = -2;
%     while jump < 2;
%         jump = jump + 1;
%     J(z,step-jump)=255;
%     end
    J(z,step)=255;%Q(z,step); %Remove all the jump section and uncomment this to get a single line 
    xpos(z,pos) = step;

else J(z,step)=0;
end
end
pos = 0;
end

subplot (151);
imagesc (Q); figure(gcf); colormap(gray)
% freezeColors;
subplot (152);
imagesc (J); figure(gcf); colormap(gray)
%freezeColors;
plotpanel = 153;
skeletonize;

